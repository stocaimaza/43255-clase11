// import React from 'react'

// const Hijo = ({herencia}) => {
//   return (
//     <div>
//         <p>Mi herencia es de {herencia.efectivo} </p>
//         <p>Recibí estos vehiculos: {herencia.vehiculos} </p>
//         <p>Y esta cantidad de propiedades: {herencia.propiedades} </p>
//         <strong>Y me la gaste toooooodaaaa ahh re loco</strong>
//     </div>
//   )
// }

// export default Hijo


/////////////////////////////////////////////////////////////////
//UTILIZANDO EL CONSUMER: 


// import React from 'react'
// import { Contexto } from '../../context/context'

// //Para poder acceder a la información se usa una función de renderizado.

// const Hijo = () => {
//     return (
//         <Contexto.Consumer>
//             {
//                 (herencia) => (
//                     <div>
//                         <p>Mi herencia es de {herencia.efectivo} </p>
//                         <p>Recibí estos vehiculos: {herencia.vehiculos} </p>
//                         <p>Y esta cantidad de propiedades: {herencia.propiedades} </p>
//                         <strong>Y me la gaste toooooodaaaa ahh re loco</strong>
//                     </div>
//                 )
//             }

//         </Contexto.Consumer>
//     )
// }

// export default Hijo

import { Contexto } from '../../context/context'
import { useContext } from 'react'

//UTILIZANDO EL HOOK USECONTEXT
//En lugar de usar el Consumen y una función de renderizado yo puedo utilizar el Hook useContext. 

//1) Importamos el contexto. 
//2) Importamos el Hook useContext. 
//3) Creamos una variable que almacene el valor del contexto. LLamo al Hook useContext y le paso el contexto como argumento. 


import React from 'react'

const Hijo = () => {
    const herencia = useContext(Contexto);

  return (
    <div>
        <p>Recibi de plata: {herencia.efectivo} </p>
        <p>Choque estos autos: {herencia.vehiculos} </p>
        <p>Y estas casas vendi: {herencia.propiedades} </p>
    </div>
  )
}

export default Hijo