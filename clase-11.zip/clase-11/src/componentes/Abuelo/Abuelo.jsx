import Padre from "../Padre/Padre"

const Abuelo = ({herencia}) => {
  return (
    <Padre herencia = {herencia} />
  )
}

export default Abuelo