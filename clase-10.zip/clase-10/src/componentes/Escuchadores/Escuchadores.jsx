import { useEffect } from "react";

//También podemos utilizar los "event listeners"
// Objeto Window
// Este objeto global representa  a la ventana del navegador. 

const Escuchadores = () => {
    //Llamando a objeto window y el método AddEventListener: 
    window.addEventListener("resize", () => console.log("Cambiaste la pantalla!!"));

    window.addEventListener("click", ()=>console.log("Click"));

    //Lo correcto sería utilizar useEffect: 

    useEffect(() => {
        function click() {
            console.log("click");
        }

        window.addEventListener("click", click);

        return () => {
            window.removeEventListener("click", click);
        }
    }, [])

  return (
    <div>Escuchadores</div>
  )
}

export default Escuchadores