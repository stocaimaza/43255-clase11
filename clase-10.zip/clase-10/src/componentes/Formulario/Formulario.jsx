import { useState } from "react"

/* EVENTOS CON EL FORMULARIO */

//onSubmit = y lo trabajos directamente con el form. 


const Formulario = () => {
    //Creamos los estados para cada campo del formulario. 
    const [nombre, setNombre] = useState("");
    const [apellido, setApellido] = useState("");
    const [email, setEmail] = useState("");

    //Creamos el manejador para el evento submit
    const handlerFormulario = (e) => {
        e.preventDefault();
        //Evitamos la recarga de la página al enviar el formulario. 

        const nuevoCliente = {nombre, apellido, email};
        console.log(nuevoCliente);

        //e.target.value = "";
        setNombre("");
        setApellido("");
        setEmail("");
    }

  return (
    <form onSubmit={handlerFormulario}>
        <label htmlFor=""> Nombre </label>
        <input type="text" onChange={(e)=> setNombre(e.target.value)} value={nombre}/>

        <label htmlFor=""> Apellido </label>
        <input type="text" onChange={(e)=> setApellido(e.target.value)} value={apellido}/>

        <label htmlFor=""> Correo Electrónico </label>
        <input type="email" onChange={(e)=> setEmail(e.target.value) } value={email} />

        <button type="submit"> Enviar Datos </button>
    </form>
  )
}

export default Formulario