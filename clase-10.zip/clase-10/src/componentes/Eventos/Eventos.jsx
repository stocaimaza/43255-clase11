import { useState } from 'react';
import './Eventos.css'
/** EVENTOS **/

//1) Eventos Manuales. 
//2) Eventos Automáticos. 

//Recordemos: EN JS vainilla usamos para eventos. 

//1) AddEventListener. 
//2) Propiedad de los nodos. 
/*

    const tituloPrincipal = document.getElementById("titulo"); 
    tituloPrincipal.onMouseMove = (acá trabajamos con una propiedad del nodo)
*/

//3) Era como un atributo en las etiquetas HTML. 

const Eventos = () => {
    const [input, setInput] = useState("");

    const manejadoraInput = (event) => {
        //Voy a trabajar con el objeto "event". 
        setInput(event.target.value);
        //La propiedad target es la referencia al objeto del DOM que dispara el evento. 
        //Value es el texto que ingreso el usuario. 
        console.log(input);
    }

    const manejadorClick = () => {
        console.log("Click");
    }
    //El nombre real en "inglis" es "handler". 
    //handler = manejador. 

    //onNombreEvento
  return (
    <div>
        <button onClick={manejadorClick}> Haceme Click </button>

        <div className="caja"
            onMouseMove={()=> console.log("Nuevo Evento")}
            onMouseEnter={()=> console.log("Hola Mouse, entraste")}
            onMouseLeave={()=> console.log("Saliste")}
            >

        </div>

        <form>
            <h2> {input} </h2>
            <label htmlFor="campo"> Ingrese Texto </label>
            <input type="text" id='campo' 
                onChange={manejadoraInput}
                onKeyDown={()=> console.log("Presionaste una tecla")}
                onKeyUp={()=> console.log("Soltaste una tecla")}
                />
            {/* htmlFor = es igual al for que usamos en HTML 
            change = se dispara cuando el usuario cambia el valor del input
            keyDown = cuando presionamos una tecla. 
            keyUp = cuando soltamos una tecla. 
            */}
        </form>
    </div>
  )
}

export default Eventos